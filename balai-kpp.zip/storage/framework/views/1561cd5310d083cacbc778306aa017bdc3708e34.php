<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous">
</script>

<div id="adModal" class="modal">
<div class="modal-content">
    <span class="close" id="closeModal">&times;</span>
    <h2>Kegiatan!</h2>
    <p><?php echo e($iklan); ?></p>
    <img src="<?php echo e(asset('dokumentasi_kegiatan/' . $iklan->dokumentasi)); ?>" style="height: 200px; object-fit: cover"
        alt="Advertisement" class="img-fluid" style="border-radius: 10px; width: 100%;">
    <div style="margin-top: 20px;">
        <button class="btn btn-secondary" style="width: 45%" id="closeModalFooter">Close</button>
        <a href="/kegiatan/<?php echo e($iklan->nama_kegiatan); ?>/<?php echo e($iklan->id); ?>" class="btn btn-primary"
            style="width: 45%">Learn More</a>


    </div>
</div>
</div><?php /**PATH C:\xampp\htdocs\LARAVEL\balai-kpp\resources\views/admin/index.blade.php ENDPATH**/ ?>