

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.1/dist/leaflet.css"
        integrity="sha512-Rksm5RenBEKSKFjgI3a41vrjkw4EVPlJ3+OiI65vTjIdo9brlAacEuKOiQ5OFh7cOI1bkDwLqdLw3Zg0cRJAAQ=="
        crossorigin="" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.Default.css" />

    <style>
        #mapid {
            min-height: 500px;
        }

        table tr th {
            text-align: center;
        }

        td {
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!-- Make sure you put this AFTER Leaflet's CSS -->
    <script src="https://unpkg.com/leaflet@1.3.1/dist/leaflet.js"
        integrity="sha512-/Nsx9X4HebavoBvEBuyp3I7od5tA0UzAxs+j83KgC8PU0kgB4XiK4Lfe4y4cgBtaRJQEIFCW+oC506aPT2L1zw=="
        crossorigin=""></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster.js"></script>

    <script>
        var map = L.map('mapid').setView([<?php echo e(config('leaflet.map_center_latitude')); ?>,
            <?php echo e(config('leaflet.map_center_longitude')); ?>

        ], <?php echo e(config('leaflet.zoom_level')); ?>);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
        var markers = L.markerClusterGroup();

        axios.get('<?php echo e(route('api.peta.index')); ?>')
            .then(function(response) {
                var marker = L.geoJSON(response.data, {
                    pointToLayer: function(geoJsonPoint, latlng) {
                        return L.marker(latlng).bindPopup(function(layer) {
                            return layer.feature.properties.map_popup_content;
                        });
                    }
                });
                markers.addLayer(marker);
            })
            .catch(function(error) {
                console.log(error);
            });
        map.addLayer(markers);

        var theMarker;
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        use App\Models\Tb_kategori_konten;
        use App\Models\Tb_artikel;
        use Illuminate\Support\Carbon;
    ?>
    <style>
        .card-artikel {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            width: 100%;
            border-radius: 13px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .card-artikel:hover {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .list-tile__title {
            margin: 0;
            font-size: 1.1em;
            color: #333;
            font-weight: bold;
        }

        .list-tile__subtitle {
            margin: 5px 0 0;
            font-size: 0.9em;
            color: #666;
        }
    </style>
    <br><br><br>
    <div class="container  mt-5" style="margin-top: 30px;">
        <?php if($submenu->konten->halaman != ''): ?>
            <?php if($submenu->konten->halaman->judul): ?>
                <header class="section-header">
                    <p class="mt-4 text-uppercase"><?php echo e($submenu->konten->halaman->judul); ?></p>
                </header>
            <?php endif; ?>
            
            <div class="row">
                <?php if($submenu->konten->halaman->atas_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Kalender Widget'): ?>
                    <div class="col-lg-4">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-widget','data' => []]); ?>
<?php $component->withName('kalender-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php
                    $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->atas_tengah);
                ?>
                <?php if($submenu->konten->halaman->atas_tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Video::class, []); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9)): ?>
<?php $component = $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9; ?>
<?php unset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Ebook::class, []); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a)): ?>
<?php $component = $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a; ?>
<?php unset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Kalender'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-besar','data' => []]); ?>
<?php $component->withName('kalender-besar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif(isset($kategoriKonten)): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->atas_tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(3);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="row">
                                <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-12 mt-3">
                                        <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                            <div class="row card-artikel">
                                                <img src="<?php echo e($item->gambar()); ?>"
                                                    style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                    alt="Avatar" class="col-2">
                                                <div class="col">
                                                    <h3 class="list-tile__title"><?php echo e($item->judul); ?></h3>
                                                    <span class="list-tile__subtitle"
                                                        style=""><?php echo e(Carbon::parse($item->tgl_pembuatan)->translatedFormat('D, d F Y')); ?>

                                                    </span>
                                                    <div class="text-primary">Lihat Detail</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->atas_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Kalender Widget'): ?>
                    <div class="col-lg-4">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-widget','data' => []]); ?>
<?php $component->withName('kalender-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if($submenu->konten->halaman->gambar != null): ?>
                <img class="rounded"
 style="width: 100%"                    src="<?php echo e($submenu->konten->halaman ? $submenu->konten->halaman->gambar() : 'no_image'); ?>" alt="Gambar">
            <?php endif; ?>

            <?php if($submenu->konten->halaman->teks): ?>
                <div class="card border-0">
                    <?php echo $submenu->konten->halaman->teks; ?>

                </div>
            <?php endif; ?>
            
            <div class="row">
                <?php if($submenu->konten->halaman->tengah_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->tengah_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php
                    $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->tengah);
                ?>
                <?php if($submenu->konten->halaman->tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->tengah == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Video::class, []); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9)): ?>
<?php $component = $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9; ?>
<?php unset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Ebook::class, []); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a)): ?>
<?php $component = $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a; ?>
<?php unset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Kalender'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-besar','data' => []]); ?>
<?php $component->withName('kalender-besar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif(isset($kategoriKonten)): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 mt-3">
                                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                                <div class="row card-artikel">
                                                    <img src="<?php echo e($item->gambar()); ?>"
                                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                        alt="Avatar" class="col-2">
                                                    <div class="col">
                                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                                        <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>

                        
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->tengah_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->tengah_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            
            <div class="row">
                <?php if($submenu->konten->halaman->bawah_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->bawah_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php
                    $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->bawah_tengah);
                ?>
                <?php if($submenu->konten->halaman->bawah_tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Video::class, []); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9)): ?>
<?php $component = $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9; ?>
<?php unset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Ebook::class, []); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a)): ?>
<?php $component = $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a; ?>
<?php unset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Kalender'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-besar','data' => []]); ?>
<?php $component->withName('kalender-besar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif(isset($kategoriKonten)): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->bawah_tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 mt-3">
                                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                                <div class="row card-artikel">
                                                    <img src="<?php echo e($item->gambar()); ?>"
                                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                        alt="Avatar" class="col-2">
                                                    <div class="col">
                                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                                        <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>

                        
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->bawah_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->bawah_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
        <?php elseif($submenu->konten->artikel != ''): ?>
            <?php if($submenu->konten->artikel->gambar != null): ?>
                <img class="rounded"
 style="width: 100%"                    src="<?php echo e($submenu->konten->artikel ? $submenu->konten->artikel->gambar() : 'no_image'); ?>"
                    alt="Gambar">
            <?php endif; ?>
            <h1 class="mt-4 text-uppercase"><?php echo e($submenu->konten->artikel->judul); ?></h1>
            <div class="card border-0">
                <?php echo $submenu->konten->artikel->teks; ?>

            </div>
        <?php elseif($submenu->konten->kategoriArtikel != ''): ?>
            <?php
                // use App\Models\Tb_kategori_artikel;
                $artikel = Tb_artikel::where('id_kategori_artikel', $submenu->konten->kategoriArtikel->id)
                    ->orderBy('created_at', 'desc')
                    ->paginate(8);
            ?>
            <h5 class="mt-4"><b> Kategori <?php echo e($submenu->konten->kategoriArtikel->nama); ?></b></h5>
            <div class="" data-aos="fade-up">
                <div class="" data-aos="fade-up">
                    <div class="row">
                        <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6 mt-3">
                                <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                    <div class="row card-artikel">
                                        <img src="<?php echo e($item->gambar()); ?>"
                                            style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                            alt="Avatar" class="col-2">
                                        <div class="col">
                                            <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                            <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <center>
                <?php echo $artikel->links(); ?>

            </center>
        <?php elseif($submenu->konten->kegiatan != ''): ?>
            <?php if($submenu->konten->kegiatan->gambar != null): ?>
                <img class="rounded " style="width: 100%"
                    src="<?php echo e($submenu->konten->kegiatan ? $submenu->konten->kegiatan->gambar() : 'no_image'); ?>"
                    alt="Gambar">
            <?php endif; ?>
            <h1 class="mt-4 text-uppercase"><?php echo e($submenu->konten->kegiatan->judul); ?></h1>
            <div class="card border-0">
                <?php echo $submenu->konten->kegiatan->teks; ?>

            </div>
        <?php else: ?>
            <br><br><br>
            <center>Tidak Ada Konten</center>
            <br><br>
            <br>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\balai-kpp\resources\views/member/submenu.blade.php ENDPATH**/ ?>