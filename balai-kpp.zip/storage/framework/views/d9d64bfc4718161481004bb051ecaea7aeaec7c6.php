

<?php $__env->startSection('content'); ?>
<!-- Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        .gradient-btn {
            background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            border: none;
            color: white;
            padding: 10px 20px;
            width: 100%;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            transition: background 0.3s ease-in-out;
            border-radius: 25px;
        }

        .gradient-btn:hover {
            background: linear-gradient(45deg, #bc1888 0%, #cc2366 25%, #dc2743 50%, #e6683c 75%, #f09433 100%);
        }

        
    </style>
    <br><br><br>
    <div class="container py-3">
        <div class="container">
            <h5 class="text-center text--primary mb-4 mt-5">Konten Instagram</h5>
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-3">
                    <div class="card shadow border-0" style="border-radius: 20px; height: 450px;">
                        <div class="card-body">
                            <?php if($post['media_type'] === 'IMAGE'): ?>
                                <img src="<?php echo e($post['media_url']); ?>" class="card-img-top"
                                     style="border-radius: 10px; height: 300px; object-fit: cover;">
                            <?php elseif($post['media_type'] === 'VIDEO'): ?>
                                <video controls class="card-img-top" style="border-radius: 10px; height: 300px;">
                                    <source src="<?php echo e($post['media_url']); ?>" type="video/mp4">
                                </video>
                            <?php elseif($post['media_type'] === 'CAROUSEL_ALBUM'): ?>
                                <div id="carousel-<?php echo e($post['id']); ?>" class="carousel slide">
                                    <div class="carousel-inner">
                                        <?php $__currentLoopData = $post['carousel_media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                                                <?php if($media['media_type'] === 'IMAGE'): ?>
                                                    <img src="<?php echo e($media['media_url']); ?>" class="d-block w-100"
                                                         style="border-radius: 10px; height: 300px; object-fit: cover;">
                                                <?php elseif($media['media_type'] === 'VIDEO'): ?>
                                                    <video controls class="d-block w-100" style="border-radius: 10px; height: 300px;">
                                                        <source src="<?php echo e($media['media_url']); ?>" type="video/mp4">
                                                    </video>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <a class="carousel-control-prev" href="#carousel-<?php echo e($post['id']); ?>" role="button" data-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Previous</span>
                                        </a>
                                        <a class="carousel-control-next" href="#carousel-<?php echo e($post['id']); ?>" role="button" data-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Next</span>
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <p class="card-text"><?php echo e(Str::limit($post['caption'], 27)); ?>.</p>
                            <a href="<?php echo e($post['permalink']); ?>" target="_blank" class="btn btn-primary gradient-btn">Show Content</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/notivemy/bkpp.notive.my.id/resources/views/instagram.blade.php ENDPATH**/ ?>