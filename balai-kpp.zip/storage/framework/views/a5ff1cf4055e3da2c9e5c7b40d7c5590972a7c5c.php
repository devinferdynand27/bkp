

<?php $__env->startSection('content'); ?>
    <?php
        use Illuminate\Support\Carbon;
        use App\Models\Tb_ebook;
    ?>
    
    <br> <br> <br>
    <section id="blog" class="blog">
        <div class="container" data-aos="fade-up">

            <div class="row">

                <div class="col-lg-8 entries">

                    <article class="entry entry-single">

                        <div class="row">
                            <div class="col-sm-4">
                                <img src="<?php echo e($ebook->gambar()); ?>" alt="" class="rounded" style="width: 200px;">
                            </div>
                            <div class="col-sm">
                                <h3>
                                    <b><?php echo e($ebook->judul); ?></b>
                                </h3>
                                <?php if($ebook->file != null): ?>
                                    <a href="/images/ebook/file/<?php echo e($ebook->file); ?>" class="btn btn-primary btn-sm"
                                        target="_blank">Lihat
                                        E-book</a>
                                <?php elseif($ebook->link != null): ?>
                                    <a href="<?php echo e($ebook->link); ?>" class="btn btn-primary btn-sm" target="_blank">Lihat
                                        E-book</a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <br>


                        <div class="entry-meta">
                            <ul>
                                <li class="d-flex align-items-center"><i class="bi bi-person"></i><?php echo e($ebook->user->name); ?>

                                </li>
                                <li class="d-flex align-items-center"><i class="bi bi-calendar"></i><time
                                        datetime="2020-01-01"><?php echo e(Carbon::parse($ebook->tgl_pembuatan)->translatedFormat('D, d F Y')); ?></time></a>
                                </li>
                                <li class="d-flex align-items-center"><i
                                        class="bi bi-clock"></i><time><?php echo e($ebook->waktu_pembuatan); ?></time></a>
                                </li>
                                <li class="d-flex align-items-center"><i class="bi bi-eye"></i><time><?php echo e($ebook->viewer); ?>

                                        Viewer</time></a>
                                </li>
                            </ul>
                        </div>
                        
                        <!-- Input untuk URL artikel -->
                        <input type="text" id="articleUrl" value="<?php echo e($url); ?>" hidden>

                        <script>
                            function copyUrlInstagram() {
                                var copyText = document.getElementById("articleUrl");
                                copyText.select();
                                copyText.setSelectionRange(0, 99999); // For mobile devices
                                document.execCommand("copy");
                                alert("Link berhasil disalin: " + copyText.value);
                            }
                        </script>

                        <div class="entry-content mt-3">

                            <?php echo $ebook->teks; ?>

                        </div>

                    </article><!-- End blog entry -->
                </div><!-- End blog entries list -->

                <div class="col-lg-4">

                    <div class="sidebar">
                        <h3 class="sidebar-title">Kategori</h3>
                        <div class="sidebar-item categories">
                            <ul>
                                <?php $__currentLoopData = $kategoriEbook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $ebookKategori = Tb_ebook::where('id_kategori_ebook', $item->id)->get();
                                        $no = $ebookKategori->count();
                                    ?>
                                    <li><a
                                            href="/ebook/<?php echo e($item->slug); ?>"><?php echo e($item->nama); ?><span>(<?php echo e($no); ?>)</span></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div><!-- End sidebar categories-->

                        <h3 class="sidebar-title">Ebook Terkait</h3>
                        <div class="sidebar-item recent-posts">
                            <?php
                                $ebookl = Tb_ebook::where('id_kategori_ebook', $ebook->id_kategori_ebook)
                                    ->inRandomOrder()
                                    ->limit(6)
                                    ->get();
                            ?>
                            <?php $__currentLoopData = $ebookl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data->id != $ebook->id): ?>
                                    <div class="post-item clearfix">
                                        <img src="<?php echo e($data->gambar()); ?>" alt="">
                                        <h4><a
                                                href="/ebook/<?php echo e($data->kategoriEbook->slug); ?>/<?php echo e($data->slug); ?>"><?php echo e($data->judul); ?></a>
                                        </h4>
                                        <time
                                            datetime="2020-01-01"><?php echo e(Carbon::parse($data->created_at)->translatedFormat('D, d F Y')); ?></time>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div><!-- End sidebar recent posts-->


                    </div><!-- End sidebar -->

                </div><!-- End blog sidebar -->

            </div>

        </div>

    </section>
    

    <script type="text/javascript">
        document.querySelector('.refresh-captcha').addEventListener('click', function() {
            var captchaImage = document.querySelector('.captcha-img');
            var captchaSrc = captchaImage.src.split('?')[0];
            captchaImage.src = captchaSrc + '?' + Math.random();
        });
    </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/notivemy/bkpp.notive.my.id/resources/views/member/ebook-detail.blade.php ENDPATH**/ ?>