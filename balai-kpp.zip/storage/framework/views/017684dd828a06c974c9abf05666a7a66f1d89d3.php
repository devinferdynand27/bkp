<div>
    <?php
        use App\Models\KalenderKegiatan;
        use App\Models\LinkKegiatan;
        $year_all = KalenderKegiatan::orderBy('created_at', 'asc')
            ->get()
            ->pluck('waktu_kegiatan')
            ->map(function ($date) {
                return date('Y', strtotime($date));
            })
            ->unique()
            ->values();

        $selected_year = request()->get('year');

        $kalender = KalenderKegiatan::query()
            ->when($selected_year, function ($query, $year) {
                return $query->whereYear('waktu_kegiatan', $year);
            })
            ->orderBy('created_at', 'asc')
            ->get();
    ?>
    <section id="recent-blog-posts" class="recent-blog-posts">
        <div class="" data-aos="fade-up">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8">
                            
                        </div>
                        <div class="col-md-4">
                            <div style="font-size: 12px;">Pilih Tahun</div>
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <select name="year" class="form-select" style="width: 100%">
                                                <option value="">-- pilih tahun --</option>
                                                <?php $__currentLoopData = $year_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item); ?>"
                                                        <?php echo e($item == $selected_year ? 'selected' : ''); ?>>
                                                        <?php echo e($item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td></td>
                                        <td><button type="submit" class="btn btn-primary btn-sm">Cari</button></td>
                                    </tr>
                                </table>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th rowspan="2" class="text-center">Nama Kegiatan</th>
                                    <th colspan="12" class="text-center">Pelaksanaan</th>
                                    <th rowspan="2" class="text-center">Tanggal</th>
                                    <th rowspan="2" class="text-center">Waktu</th>
                                    <th rowspan="2" class="text-center">Link</th>
                                    <th rowspan="2" class="text-center">Status</th>
                                </tr>
                                <tr>
                                    <th>Jan</th>
                                    <th>Feb</th>
                                    <th>Mar</th>
                                    <th>Apr</th>
                                    <th>Mei</th>
                                    <th>Jun</th>
                                    <th>Jul</th>
                                    <th>Ags</th>
                                    <th>Sep</th>
                                    <th>Okt</th>
                                    <th>Nov</th>
                                    <th>Des</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kalender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $bulan = \Carbon\Carbon::parse($item->waktu_kegiatan)->format('n'); // Mendapatkan bulan (1-12)
                                        $tanggal = \Carbon\Carbon::parse($item->waktu_kegiatan)->format('d'); // Mendapatkan tanggal (01-31)
                                    ?>
                                    <tr>
                                        <td><?php echo e($item->nama_kegiatan); ?></td>
                                        <?php for($i = 1; $i <= 12; $i++): ?>
                                            <td class="text-center">
                                                <?php if($i == $bulan): ?>
                                                    <div class="select-date btn btn-warning btn-sm"
                                                        style="cursor: pointer"
                                                        onclick="modal_show(<?php echo e($item->id); ?>)">
                                                        <?php echo e($tanggal); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                        <?php endfor; ?>
                                        <td><?php echo e(\Carbon\Carbon::parse($item->waktu_kegiatan)->format('Y-m-d')); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($item->waktu_kegiatan)->format('H:i')); ?></td>
                                        <td>
                                            <button type="button" onclick="alert('Masi dalam Pengembangan')" class="btn btn-primary btn-sm"
                                                id="openModalBtn<?php echo e($item->id); ?>">
                                                Link
                                                <i class="bi bi-link-45deg"></i>
                                            </button>
                                        </td>
                                        <td>
                                            <div
                                                class="<?php echo e($item->status == 0 ? 'btn btn-secondary btn-sm' : 'btn btn-primary btn-sm'); ?>">
                                                <?php echo e($item->status == 1 ? 'Sudah Terlaksana' : 'Belum Terlaksana'); ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Move modals outside of the card -->
    <?php $__currentLoopData = $kalender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $data_lkid = $item->data_lkid;
            $arrayData = json_decode($data_lkid, true);
            $intArray = array_map('intval', $arrayData);
            $link = LinkKegiatan::orderBy('created_at', 'asc')->whereIn('id', $arrayData)->get();
        ?>
      
      


        <div id="modal<?php echo e($item->id); ?>" class="custom-modal">
            <div class="custom-modal-content shadow">
                <span class="close-modal">&times;</span>
                <h6><?php echo e($item->nama_kegiatan); ?></h6>
                <img style="width: 100%" src="<?php echo e(asset('dokumentasi_kegiatan/' . $item->dokumentasi)); ?>"
                    alt=""><br><b></b><br>

                <span style="color: gray" class="mt-2"><?php echo e($item->waktu_kegiatan); ?></span>
                <p class="mt-3"><?php echo e($item->deskripsi); ?></p>
                <div style="display: flex;" class="">
                    <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($item->url); ?>" target="_blank" class="btn btn-sm text-white"
                            style="background: <?php echo e($item->color); ?>"><img style="width: 20px"
                                src="<?php echo e(asset('icon/' . $item->icon)); ?>" alt="" srcset=""> &nbsp;
                            <?php echo e($item->name); ?></a> &nbsp;
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<style>
    /* The Modal Background */
    .custom-modal {
        display: none;
        /* Hidden by default */
        position: fixed;
        /* Stay in place */
        z-index: 1050;
        /* Sit on top of other content */
        left: 0;
        top: 0;
        width: 100%;
        /* Full width */
        height: 100%;
        /* Full height */
        overflow: auto;
        /* Enable scroll if needed */
    }

    /* Modal Content Box */
    .custom-modal-content {
        background-color: white;
        margin: 0 auto;
        /* Center horizontally */
        padding: 20px;
        width: 80%;
        /* Could be more or less, depending on screen size */
        max-width: 500px;
        max-height: 80vh;
        /* Limit the height to 80% of the viewport height */
        overflow-y: auto;
        /* Enable vertical scrolling */
        border-radius: 10px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        /* Add some shadow for better visibility */
        position: relative;
        top: 10%;
        /* Adjust as needed to center vertically */
        animation-name: slideDown;
        animation-duration: 0.5s;
        animation-timing-function: ease-out;
        animation-fill-mode: forwards;
    }

    /* The Close Button */
    .close-modal {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close-modal:hover,
    .close-modal:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    /* Slide Down Animation */
    @keyframes  slideDown {
        from {
            top: -100%;
        }

        to {
            top: 10%;
        }
    }
</style>
<script>
    function modal_show(id) {
        var modal = document.getElementById("modal" + id);
        var closeModal = modal.querySelector('.close-modal');

        // Display the modal
        modal.style.display = "flex";

        // Close the modal when clicking on the close button
        closeModal.onclick = function() {
            modal.style.display = "none";
        }

        // Close the modal when clicking outside the modal content
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    }

    // Optional: Close the modal if the user clicks anywhere outside of the modal content
    window.onclick = function(event) {
        if (event.target === document.getElementById('myModal')) {
            modal_close();
        }
    }

    document.querySelectorAll('.copy-btn').forEach(button => {
        button.addEventListener('click', function() {
            // Get the selector from the data-clipboard-target attribute
            const targetSelector = this.getAttribute('data-clipboard-target');
            const targetInput = document.querySelector(targetSelector);

            // Select the input field's content
            if (targetInput) {
                targetInput.select();
                document.execCommand('copy');

                // Provide user feedback
                this.textContent = 'Copied!';
                setTimeout(() => {
                    this.textContent = 'Copy';
                }, 2000);
            }
        });
    });

    // This function will attach event listeners to each button with a dynamic ID
    document.querySelectorAll('[id^="openModalBtn"]').forEach(function(btn) {
        var id = btn.id.replace('openModalBtn', '');
        var modal = document.getElementById("customModal" + id);
        var closeModal = modal.querySelector('.close-modal');

        btn.onclick = function() {
            modal.style.display = "flex";
        }

        closeModal.onclick = function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    });
</script>
<?php /**PATH C:\xampp\htdocs\LARAVEL\balai-kpp\resources\views/components/kalender-besar.blade.php ENDPATH**/ ?>