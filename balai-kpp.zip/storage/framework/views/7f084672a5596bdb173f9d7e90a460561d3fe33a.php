<?php
    use App\Models\Tb_kategori_galeri;
    $kategoriGaleri = Tb_kategori_galeri::all();
?>
<div>
    <div class="container mb-5">
        <section id="recent-blog-posts" class="recent-blog-posts">

            <div class="container" data-aos="fade-up">
                
                
                
                <div class="row">
                    <?php $__currentLoopData = $kategoriGaleri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="post-box">
                                <div class="post-img"><img src="<?php echo e($item->cover()); ?>" class="img-fluid" alt="">
                                </div>
                                <h3 class="post-title"><?php echo e($item->nama); ?></h3>
                                <a href="galeri/<?php echo e($item->slug); ?>"
                                    class="readmore stretched-link mt-auto"><span>Lihat</span><i
                                        class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </div>
</div>
<?php /**PATH /home/notivemy/bkpp.notive.my.id/resources/views/components/galeri.blade.php ENDPATH**/ ?>