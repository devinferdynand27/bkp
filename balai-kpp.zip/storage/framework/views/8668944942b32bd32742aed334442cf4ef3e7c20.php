

<?php $__env->startSection('content'); ?>
<?php
use Carbon\Carbon;

    $date = Carbon::parse($kalender->waktu_kegiatan);
    $formattedDate = $date->format('l, F j, Y \a\t g:i A'); // Format as "Day, Month Day, Year at Time"
?>
<div class="container"><br><br><br><br><br>
     <center>
        <h3>Kegiatan Terbaru!!</h3><br><br>
     </center>
    <div class="row ">
        <div class="col-md-6">
            <img src="<?php echo e(asset('dokumentasi_kegiatan/'.$kalender->dokumentasi)); ?>" style="width: 100%; border-radius: 20px">
        </div>
        <div class="col-md-6">
             <h4><?php echo e($kalender->nama_kegiatan); ?></h4>
             <span><?php echo e($formattedDate); ?></span><br><br>
             <p><?php echo e($kalender->deskripsi); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/notivemy/bkpp.notive.my.id/resources/views/iklan-kegiatan.blade.php ENDPATH**/ ?>