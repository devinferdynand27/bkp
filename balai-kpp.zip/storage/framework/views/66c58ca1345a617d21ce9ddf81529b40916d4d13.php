

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/assets/js/plugin/datatables/datatables.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#galeri').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('js/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('js/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Kalender Kegiatan</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="/master-admin/dashboard">
                        <i class="fa-solid fa-house-chimney"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/master-admin/module">Module</a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Kalender Kegiatan</a>
                </li>
            </ul>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-8">
                        <div class="card-title">Tambah Kalender Kegiatan</div>
                    </div>
                    <div class="col"></div>
                    <div class="col"></div>
                </div>
            </div>
            <div class="card-body">
                <form action="/master-admin/kalender-kegiatan/update/<?php echo e($kegiatan->id); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="">Nama Kegiatan</label>
                        <input type="text" name="nama_kegiatan" value="<?php echo e($kegiatan->nama_kegiatan); ?>" required
                            class="form-control" placeholder="Masukan Nama Kegiatan">
                    </div>
                    <div class="form-group">
                        <label for="">kategori kegiatan</label>
                         <select name="kkid"  class="form-control" required>
                              <?php $__currentLoopData = $kategori_kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $kegiatan->kkid ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                    </div>
                    <div class="form-group">
                        <label for="">Tanggal Kegiatan</label>
                        <input type="datetime-local" value="<?php echo e($kegiatan->waktu_kegiatan); ?>" name="waktu_kegiatan" required
                            class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Dokumentasi</label>
                        <input type="file" name="dokumentasi" value="<?php echo e($kegiatan->dokumentasi); ?>" 
                            class="form-control" placeholder="Upload Image">
                    </div>
                    <div id="form-container">
                        <div class="container">
                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="text" class="form-control" name="link[]"
                                    value="<?php echo e(htmlspecialchars($link)); ?>" /> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div class="form-group">
                        <button type="button" onclick="addLink()" class="btn btn-success btn-sm">Tambah Link</button>
                    </div>
                    <div class="form-group">
                        <label for="">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" required cols="30" rows="10"><?php echo e($kegiatan->deskripsi); ?> </textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary float-right">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        function addLink() {
            // Prevent default form submission
            event.preventDefault();

            // Create a new form group
            var newFormGroup = document.createElement('div');
            newFormGroup.className = 'form-group';

            // Create the new input element
            var newInput = document.createElement('input');
            newInput.type = 'text';
            newInput.name = 'link[]';
            newInput.required = true;
            newInput.className = 'form-control';
            newInput.placeholder = 'Masukan Link';

            // Append the input to the new form group
            newFormGroup.appendChild(newInput);

            // Append the new form group to the container
            document.getElementById('form-container').appendChild(newFormGroup);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/notivemy/bkpp.notive.my.id/resources/views/admin/kalender_kegiatan/edit.blade.php ENDPATH**/ ?>