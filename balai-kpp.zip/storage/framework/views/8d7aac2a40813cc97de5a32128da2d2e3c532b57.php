<?php
    use App\Models\Tb_menu;
    use App\Models\Tb_submenu;
    use App\Models\Tb_setting;
    use App\Models\Tb_visitor;
    $visitors = Tb_visitor::count();
    $setting = Tb_setting::find(1);
    $menu = Tb_menu::orderBy('urutan', 'asc')->get();
?>

<!-- ======= Footer ======= -->
<footer id="footer" class="footer">


    <div class="footer-top">
        <div class="container">
            <div class="row gy-4">
                <div class="col-sm footer-info">
                    <a href="/" class="logo d-flex align-items-center">
                        
                        <span><?php echo e($setting->judul); ?></span>
                    </a>
                    <p><?php echo e($setting->alamat); ?></p>
                    <?php
                        use App\Models\MediaSosial;
                        $media = MediaSosial::orderBy('created_at','asc')->get();
                    ?>
                    <br>
                    <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <a href="<?php echo e($item->link); ?>" target="_blank">
                        <img src="<?php echo e(asset('icon/'.$item->icon)); ?>" width="30px" alt="" srcset="">
                       </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-sm footer-links">
                    <h4>Menu</h4>
                    <ul>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id_konten === 0): ?>
                                <li class="nav-item dropdown">
                                    <i class="bi bi-chevron-right"></i>
                                    <a id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false" v-pre style="text-decoration: none;">
                                        <?php echo e($item->nama); ?>

                                    </a>

                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <?php
                                            $submenu = Tb_submenu::where('id_menu', $item->id)->get();
                                        ?>
                                        <?php $__currentLoopData = $submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="/s=><?php echo e($data->slug); ?>"
                                                class="dropdown-item <?php echo e(Request::is('') ? 'active text-warning' : ''); ?>"><?php echo e($data->nama); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>
                            <?php else: ?>
                                <li><i class="bi bi-chevron-right"></i> <a
                                        href="/m=><?php echo e($item->slug); ?>"><?php echo e($item->nama); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                

                <div class="col-sm footer-contact text-center text-md-start">
                    <h4>Kontak Kami</h4>
                    
                    <a href="/m=>kontak" class="btn btn-primary btn-sm mb-3">Kontak Kami</a>
                    <br>
                    <strong>Phone:</strong> <?php echo e($setting->call_us); ?><br>
                    <strong>Email:</strong> <?php echo e($setting->email_us); ?><br>
                    </p>
                    <div class="card border-0 shadow" style="border-radius: 13px;">
                        <div class="card-body">
                            <h5>Visitor: <b> <?php echo e(number_format($visitors, 0, ',', '.')); ?> </b></h5>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong><span><?php echo e($setting->judul); ?></span></strong>. All Rights Reserved
        </div>
        
    </div>
</footer><!-- End Footer -->

<script type="text/javascript">
    document.querySelector('.refresh-captcha').addEventListener('click', function() {
        var captchaImage = document.querySelector('.captcha-img');
        var captchaSrc = captchaImage.src.split('?')[0];
        captchaImage.src = captchaSrc + '?' + Math.random();
    });
</script>

<!-- Footer Start -->

<!-- Footer End -->
<?php /**PATH /home/notivemy/bkpp.notive.my.id/resources/views/layouts/partials/member/footer.blade.php ENDPATH**/ ?>