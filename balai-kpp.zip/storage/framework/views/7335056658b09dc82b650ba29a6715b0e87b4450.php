

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/assets/js/plugin/datatables/datatables.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#artikel').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('js/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('js/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ckeditor'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Instagram</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="/master-admin/dashboard">
                        <i class="fa-solid fa-house-chimney"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <?php if(Auth::user()->id == 1): ?>
                    <li class="nav-item">
                        <a href="/master-admin/module">Module</a>
                    </li>
                    <li class="separator">
                        <i class="fa-solid fa-chevron-right"></i>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="">Seting Instagram</a>
                </li>
            </ul>

        </div>
        <div class="card">
            <div class="container">
                 <form action="<?php echo e(route('instagram.store')); ?> " method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mt-3">
                        <label for="">Masukan Nama Instagram </label>
                        <input type="text" required placeholder="" value="<?php echo e($base->name); ?>" class="form-control" name="name" id="">
                        <p style="font-size: 10px" class="pl-1 mt-1">*masukan nama dengan mempertikan Uppercase dan LowerCase</p>
                    </div>
                    <div class="form-group ">
                        <label for="">Masukan Token Instagram </label>
                        <input type="text" required placeholder="" value="<?php echo e($base->token); ?>" class="form-control" name="token" id="">
                        <p style="font-size: 10px" class="pl-1 mt-1">*masukan token dengan mempertikan Uppercase dan LowerCase</p>
                    </div>
                    <div class="fotm-group">
                        <div class="container">
                            <button class="btn btn-primary btn-sm" type="submit">Simpan</button>
                        </div>
                    </div><br><br>
                 </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/notivemy/bkpp.notive.my.id/resources/views/admin/base_instagram/index.blade.php ENDPATH**/ ?>