

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/assets/js/plugin/datatables/datatables.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#menu').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('js/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('js/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ckeditor'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/34.2.0/classic/ckeditor.js"></script>

    <script>
        ClassicEditor
            .create(document.querySelector('#ckeditor'))
            .catch(error => {
                console.error(error);
            });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Menu</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="/master-admin/dashboard">
                        <i class="fa-solid fa-house-chimney"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/master-admin/menu">Menu</a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Data Menu</a>
                </li>
            </ul>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-10">
                        <div class="card-title">Data Menu</div>
                    </div>
                    <div class="col">
                        <a class="btn btn-primary text-white float-right" href="<?php echo e(route('menu.create')); ?>">Tambah
                            Menu</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table responsive-3" id="menu">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Konten</th>
                                <th>Aksi</th>
                                <th>Urutan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-header="No"><?php echo e($no++); ?></td>
                                    <td data-header="Nama Menu"><?php echo e($item->nama); ?></td>
                                    <td data-header="Isi Konten">
                                        <?php if($item->id_konten != 0): ?>
                                            <?php if($item->konten->id_halaman != null): ?>
                                                <?php echo e($item->konten->halaman->judul); ?>

                                            <?php elseif($item->konten->id_artikel != null): ?>
                                                <?php echo e($item->konten->artikel->judul); ?>

                                            <?php elseif($item->konten->id_kegiatan != null): ?>
                                                <?php echo e($item->konten->kegiatan->judul); ?>

                                            <?php elseif($item->konten->link != null): ?>
                                                <a
                                                    href="<?php echo e($item->konten->link->link); ?>"><?php echo e($item->konten->link->nama); ?></a>
                                            <?php else: ?>
                                                <span class="text-danger"> Kosong</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            #
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('menu.destroy', $item->id)); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <?php if($item->id_konten == 0): ?>
                                                <a href="/master-admin/menu/<?php echo e($item->slug); ?>/submenu"
                                                    class="btn btn-sm btn-success text-white" data-toggle="tooltip"
                                                    data-placement="top" title="SubMenu"><i
                                                        class="fa-solid fa-list"></i></a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('menu.edit', $item->id)); ?>"
                                                class="btn btn-sm btn-warning text-white" data-toggle="tooltip"
                                                data-placement="top" title="Edit"><i
                                                    class="fa-solid fa-pen-to-square"></i></a>
                                            <button type="submit" class="btn btn-danger btn-sm delete-confirm"
                                                data-toggle="tooltip" data-placement="top" title="Hapus"><i
                                                    class="fa-solid fa-trash"></i></button>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="/master-admin/urutan/<?php echo e($item->id); ?>/atas" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php if($item->urutan != 1): ?>
                                                <button type="submit" class="btn btn-primary btn-sm"><i
                                                        class="fa-solid fa-arrow-up"></i></button>
                                            <?php endif; ?>
                                        </form>
                                        <form action="/master-admin/urutan/<?php echo e($item->id); ?>/bawah" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php if($item->urutan != $menuCount): ?>
                                                <button type="submit" class="btn btn-info btn-sm"><i
                                                        class="fa-solid fa-arrow-down"></i></button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="modalSayaLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg border-0" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalSayaLabel">Tambah Data menu</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('menu.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Nama Menu</label>
                            <div class="input-group ">
                                <input type="text" value="<?php echo e(old('nama')); ?>" placeholder="Masukkan Nama menu"
                                    name="nama" autocomplete='off'
                                    class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Isi Konten</label>
                            <div class="input-group ">
                                <select name="id_konten" required class="form-control"
                                    <?php $__errorArgs = ['id_konten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="">-- Pilih Isi Konten --</option>
                                    <option value="#">Sub Menu</option>
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->id_halaman != null): ?>
                                            <option value="<?php echo e($item->id); ?>">
                                                <?php echo e($item->halaman->judul); ?> | <?php echo e($item->type); ?>

                                            </option>
                                        <?php elseif($item->id_artikel != null): ?>
                                            <option value="<?php echo e($item->id); ?>">
                                                <?php echo e($item->artikel->judul); ?> | <?php echo e($item->type); ?>

                                            </option>
                                        <?php elseif($item->id_kegiatan != null): ?>
                                            <option value="<?php echo e($item->id); ?>">
                                                <?php echo e($item->kegiatan->judul); ?> | <?php echo e($item->type); ?>

                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['id_konten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <h2>Membuat Search di Select Option</h2>
                            <select class="theSelect">
                                <option value="Codeigniter">Codeigniter</option>
                                <option value="FuelPHP">FuelPHP</option>
                                <option value="PhalconPHP">PhalconPHP</option>
                                <option value="Slim">Slim</option>
                                <option value="Silex">Silex</option>
                                <option value="CakePHP">CakePHP</option>
                                <option value="Symfony">Symfony</option>
                                <option value="Yii">Yii</option>
                                <option value="Laravel">Laravel</option>
                                <option value="Lumen">Lumen</option>
                                <option value="Zend">Zend</option>
                            </select>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary text-white">Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/notivemy/bkpp.notive.my.id/resources/views/admin/menu/index.blade.php ENDPATH**/ ?>