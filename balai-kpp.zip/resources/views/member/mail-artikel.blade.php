<!DOCTYPE html>
<html>

<head>
    <title>Email</title>
</head>

<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>
    <a href="{{ $details['link'] }}">Lihat Artikel</a>
</body>

</html>
