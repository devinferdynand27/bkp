<div class="row py-2 px-xl-5" style="background-color: #9d0c47;">
    <div class="col-lg-4 d-none d-lg-block">
        <div class="d-inline-flex align-items-center h-100">
            {{-- <a class="text-body mr-3" href="">Aset Daerah Sumedang</a> --}}
        </div>
    </div>
    <div class="col-lg-8 text-center text-lg-right">
        <div class="d-inline-flex align-items-center">
            <a href="/" class="text-white d-none d-md-block" style="margin-right: 20px;">Beranda</a>
            <a href="/tentang-kami" class="text-white d-none d-md-block" style="margin-right: 20px;">Tentang Kami</a>
            <a href="/suku-bunga" class="text-white d-none d-md-block" style="margin-right: 20px;">Suku Bunga</a>
            <a href="/artikel" class="text-white d-none d-md-block" style="margin-right: 20px;">Artikel</a>
            <a href="/informasi-lelang" class="text-white d-none d-md-block" style="margin-right: 20px;">Informasi
                Lelang</a>
            <a href="/karir" class="text-white d-none d-md-block" style="margin-right: 20px;">Karir</a>
            <a href="/lokasi-kantor" class="text-white d-none d-md-block" style="margin-right: 20px;">Lokasi Kantor</a>
            <a href="/faq" class="text-white d-none d-md-block" style="margin-right: 20px;">FAQ</a>
        </div>
    </div>
</div>
