<?php

namespace App\Http\Controllers;

use App\Models\Tb_kategori_konten_ebook;
use Illuminate\Http\Request;

class TbKategoriKontenEbookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tb_kategori_konten_ebook  $tb_kategori_konten_ebook
     * @return \Illuminate\Http\Response
     */
    public function show(Tb_kategori_konten_ebook $tb_kategori_konten_ebook)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tb_kategori_konten_ebook  $tb_kategori_konten_ebook
     * @return \Illuminate\Http\Response
     */
    public function edit(Tb_kategori_konten_ebook $tb_kategori_konten_ebook)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tb_kategori_konten_ebook  $tb_kategori_konten_ebook
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tb_kategori_konten_ebook $tb_kategori_konten_ebook)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tb_kategori_konten_ebook  $tb_kategori_konten_ebook
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tb_kategori_konten_ebook $tb_kategori_konten_ebook)
    {
        //
    }
}
