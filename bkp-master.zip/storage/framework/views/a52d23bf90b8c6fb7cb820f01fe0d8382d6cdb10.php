  <?php
      use App\Models\Tb_setting;
      use App\Models\Tb_menu;
      use App\Models\Tb_submenu;
      $setting = Tb_setting::find(1);
      $menu = Tb_menu::orderBy('urutan', 'asc')->get();
  ?>
  <!-- ======= Header ======= -->
  <header id="header" class="bg-white fixed-top shadow">
      <div class="p-3 d-flex align-items-center justify-content-between">


          
          
          <a href="/"> <img src="<?php echo e(asset('images/logo/logo.png')); ?>" class="" style="width: 300px"
                  height="50px" alt=""></a>
          

          <nav id="navbar" class="navbar">
              <ul>
                  <!--<li>-->
                  <!--    <a style="color: #2E4370;" class="nav-link scrollto" href="/">Home</a>-->
                  <!--</li>-->
                  <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($item->id_konten == 0): ?>
                          <li class="dropdown"><a style="color: #2E4370; font-size: 13px;"
                                  href="#"><span><?php echo e($item->nama); ?></span>
                                  <i class="bi bi-chevron-down"></i></a>
                              <ul>
                                  <li>
                                      <?php
                                          $submenu = Tb_submenu::orderBy('urutan', 'asc')
                                              ->where('id_menu', $item->id)
                                              ->get();
                                      ?>
                                      <?php $__currentLoopData = $submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($data->konten->link || $data->konten->link != null): ?>
                                              <a href="<?php echo e($data->konten->link->link); ?>"
                                                  style="color: #2E4370; font-size: 13px;"
                                                  class="dropdown-item <?php echo e(Request::is('') ? 'active text-warning' : ''); ?>"><?php echo e($data->nama); ?></a>
                                          <?php else: ?>
                                              <a href="/s=><?php echo e($data->slug); ?>"
                                                  style="color: #2E4370; font-size: 13px;"><?php echo e($data->nama); ?></a>
                                          <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </li>
                              </ul>
                          </li>
                      <?php else: ?>
                          <?php if($item->konten->link || $item->konten->link != null): ?>
                              <li>
                                  <a href="<?php echo e($item->konten->link->link); ?>" style="color: #2E4370; font-size: 13px;"
                                      class="dropdown-item <?php echo e(Request::is('') ? 'active text-warning' : ''); ?>"><?php echo e($item->nama); ?></a>
                              </li>
                          <?php else: ?>
                              <li><a style="color: #2E4370; font-size: 13px;" class="nav-link scrollto"
                                      href="/m=><?php echo e($item->slug); ?> "><?php echo e($item->nama); ?></a>
                              </li>
                          <?php endif; ?>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <li><a class="getstarted scrollto" href="/forum" style="background: #F7CB4F">Forum</a></li>
              </ul>
              <i class="bi bi-list mobile-nav-toggle"></i>
          </nav><!-- .navbar -->

      </div>
  </header><!-- End Header -->
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkp-master/resources/views/layouts/partials/member/header.blade.php ENDPATH**/ ?>