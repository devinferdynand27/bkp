<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/js/jquery.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/select2.css')); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>

    <script>
        $(".theSelect").select2();
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Sub Menu</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="/master-admin/dashboard">
                        <i class="fa-solid fa-house-chimney"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/master-admin/submenu">Sub Menu</a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Edit Sub Menu</a>
                </li>
            </ul>
        </div>



        <div class="card">
            <div class="card-header">
                <h4 class="card-title col-sm-10">Edit Data SubMenu</h4>
            </div>
            <div class="card-body">
                <form action="update" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Nama Sub Menu</label>
                        <div class="input-group ">
                            <input type="text" value="<?php echo e($submenu->nama); ?>" placeholder="Masukkan Nama SubMenu"
                                name="nama" autocomplete='off' class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                required>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Isi Konten</label>
                        <div class="input-group ">

                            <select name="id_konten" required class="form-control theSelect"
                                <?php $__errorArgs = ['id_konten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                <option value="">-- Pilih Isi Konten --</option>
                                <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->id_halaman != null): ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php echo e($item->id == $submenu->id_konten ? 'selected' : ''); ?>>
                                            <?php echo e($item->halaman->judul); ?> | <?php echo e($item->type); ?>

                                        </option>
                                    <?php elseif($item->id_artikel != null): ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php echo e($item->id == $submenu->id_konten ? 'selected' : ''); ?>>
                                            <?php echo e($item->artikel->judul); ?> | <?php echo e($item->type); ?>

                                        </option>
                                    <?php elseif($item->id_kegiatan != null): ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php echo e($item->id == $submenu->id_konten ? 'selected' : ''); ?>>
                                            <?php echo e($item->kegiatan->judul); ?> | <?php echo e($item->type); ?>

                                        </option>
                                    <?php elseif($item->id_link != null): ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php echo e($item->id == $submenu->id_konten ? 'selected' : ''); ?>>
                                            <?php echo e($item->link->nama); ?> | <?php echo e($item->type); ?>

                                        </option>
                                    <?php elseif($item->id_kategori_artikel != null): ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php echo e($item->id == $submenu->id_konten ? 'selected' : ''); ?>>
                                            <?php echo e($item->kategoriArtikel->nama); ?> | <?php echo e($item->type); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['id_konten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group mt-4">
                        <button type="submit" class="btn btn-warning text-white"><i class="fa fa-save mr-1"></i>
                            Simpan Perubahan</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkp-master/resources/views/admin/submenu/edit.blade.php ENDPATH**/ ?>