<?php $attributes = $attributes->exceptProps(['id']); ?>
<?php foreach (array_filter((['id']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $text = App\Models\ModuleText::find($id);
?>
<div>
    <?php echo e($sub_text); ?>

    <?php echo e($id); ?>


    <?php echo $text->text; ?>

</div>
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkp-master/resources/views/components/teks.blade.php ENDPATH**/ ?>