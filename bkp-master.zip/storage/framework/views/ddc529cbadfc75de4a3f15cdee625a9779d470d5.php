<?php $attributes = $attributes->exceptProps(['id']); ?>
<?php foreach (array_filter((['id']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $text = App\Models\ModuleText::find($id);
?>
<div>
    <h5 class="text--primary mb-4 mt-4"><?php echo e($text->judul); ?></h5>
    
    <p><?php echo $text->text; ?></p>
</div>
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkp-master/resources/views/components/text.blade.php ENDPATH**/ ?>