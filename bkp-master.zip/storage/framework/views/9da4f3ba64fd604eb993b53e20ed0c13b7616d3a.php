<?php
    use App\Models\Tb_menu;
    use App\Models\Tb_submenu;
    use App\Models\Tb_setting;
    use App\Models\Tb_visitor;
    $visitors = Tb_visitor::count();
    $setting = Tb_setting::find(1);
    $menu = Tb_menu::orderBy('urutan', 'asc')->get();
?>

<!-- ======= Footer ======= -->
<footer id="footer" class="footer">


    <div class="footer-top">
        <div class="container">
            <div class="row gy-4">

                <div class="col-sm footer-info">
                    <h3 style="color: navy"> <span><?php echo e($setting->judul); ?></span></h3>

                    <p><?php echo $setting->alamat; ?></p>
                    <?php
                        use App\Models\MediaSosial;
                        $media = MediaSosial::orderBy('created_at', 'asc')->get();
                    ?>
                    <br>
                    <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($item->link); ?>" target="_blank">
                            <img src="<?php echo e(asset('icon/' . $item->icon)); ?>" width="30px" alt="" srcset="">
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-sm footer-links">
                    <h4>Lokasi</h4>
                    <center>
                        <iframe style="width: 400px; height: 200px;"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.5113554464683!2d107.7501229741071!3d-6.948846068026497!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68c30c7c6fe19f%3A0xd3d3febec0610024!2sBalai%20Kawasan%20Permukiman%20dan%20Perumahan!5e0!3m2!1sid!2sid!4v1725693993980!5m2!1sid!2sid"
                            width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </center>
                </div>

                

                <div class="col-sm footer-contact text-center text-md-start">
                    <h4>Kontak Kami</h4>
                    
                    <a href="/m=>kontak" class="btn  text-white btn-sm mb-3" style="background: #374774">Kontak Kami</a>
                    <br>
                    <strong>Phone:</strong> <?php echo e($setting->call_us); ?><br>
                    <strong>Email:</strong> <?php echo e($setting->email_us); ?><br>
                    </p>
                    <div class="card border-0 shadow" style="border-radius: 13px;">
                        <div class="card-body">
                            <h5>Visitor: <b> <?php echo e(number_format($visitors, 0, ',', '.')); ?> </b></h5>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong><span><?php echo e($setting->judul); ?></span></strong>. All Rights Reserved
        </div>
        
    </div>
</footer><!-- End Footer -->

<script type="text/javascript">
    document.querySelector('.refresh-captcha').addEventListener('click', function() {
        var captchaImage = document.querySelector('.captcha-img');
        var captchaSrc = captchaImage.src.split('?')[0];
        captchaImage.src = captchaSrc + '?' + Math.random();
    });
</script>

<!-- Footer Start -->

<!-- Footer End -->
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkp-master/resources/views/layouts/partials/member/footer.blade.php ENDPATH**/ ?>