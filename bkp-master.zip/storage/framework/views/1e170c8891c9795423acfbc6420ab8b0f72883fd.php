    <?php
        use App\Models\Tb_ebook;
        $ebook = Tb_ebook::orderBy('created_at', 'desc')->paginate(10);
    ?>
    <div>
        <div class="container">
            <section id="recent-blog-posts" class="recent-blog-posts">
                <div class="" data-aos="fade-up">
                    <div class="row">
                        <?php $__currentLoopData = $ebook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3">
                                <div class="card shadow border-0 mb-2">
                                    <div class="card-body">
                                        <center>
                                            <div class=""><img src="<?php echo e($item->gambar()); ?>" class="rounded"
                                                    style="height: 200px; width: 100%; object-fit: cover;"
                                                    alt="">
                                            </div>
                                            <br>
                                            <h6 class=""><b> <?php echo e(Str::limit($item->judul, 50)); ?> </b></h6>
                                            <a href="/ebook/<?php echo e($item->kategoriEbook->nama); ?>/<?php echo e($item->slug); ?>"
                                                class="readmore stretched-link mt-auto">
                                            </a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <br>
                <center>
                    <?php echo $ebook->links(); ?>

                </center>
            </section>
        </div>
    </div>
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkp-master/resources/views/components/ebook.blade.php ENDPATH**/ ?>