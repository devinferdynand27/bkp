<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Admin</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">

    <!-- Fonts and icons -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/webfont/webfont.min.js')); ?>"></script>
    <script>
        WebFont.load({
                    google: {
                        "families": ["Lato:300,400,700,900"]
                    },
                    custom: {
                        "families": ["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands",
                            "simple-line-icons"
                        ],
                        urls: ['
                            assets / admin / css / fonts.min.css ']
                        },
                        active: function() {
                            sessionStorage.fonts = true;
                        }
                    });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/atlantis.min.css')); ?>">

    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/demo.css')); ?>">
</head>

<style>
    body {
        background: white;
        /* background: linear-gradient(to right, rgb(0, 0, 119), #0004df); */
    }
</style>

<body><br><br><br>

    <center>
        
        <br><br>


        <div class="container">
            
          

            <div class="card mx-auto mt-4" style="width: 100%; max-width: 400px;">
                <div class="card-body p-4">
                    <h4 class="card-title mb-4 mt-3">Login Admin BKPP</h4>
                    <img src="<?php echo e(asset('images/logo/logo.png')); ?>" style="width:100%" alt="">
                    <hr>
                    <form action="/master-admin/login/proses" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <input type="text" id="email" name="email" value="<?php echo e(old('email')); ?>"
                                   class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block">
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group mb-4">
                            <input type="password" id="password" name="password"
                                   class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block">
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <p>Silahkan login untuk keamanan bersama</p>
                        <div class="d-grid">
                            <button type="submit" style="width: 95%" class="btn btn-primary">Login</button>
                        </div>
                    </form>
                </div>
            </div>
            
            
            

            
        </div>
    </center>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets/admin/js/core/jquery.3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/core/bootstrap.min.js')); ?>"></script>

    <!-- jQuery UI -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js')); ?>"></script>

    <!-- jQuery Scrollbar -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>


    <!-- Chart JS -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/chart.js/chart.min.js')); ?>"></script>

    <!-- jQuery Sparkline -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/jquery.sparkline/jquery.sparkline.min.js')); ?>"></script>

    <!-- Chart Circle -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/chart-circle/circles.min.js')); ?>"></script>

    <!-- Datatables -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/datatables/datatables.min.js')); ?>"></script>

    <!-- Bootstrap Notify -->
    

    <!-- jQuery Vector Maps -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/jqvmap/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/plugin/jqvmap/maps/jquery.vmap.world.js')); ?>"></script>

    <!-- Sweet Alert -->
    <script src="<?php echo e(asset('assets/admin/js/plugin/sweetalert/sweetalert.min.js')); ?>"></script>

    <!-- Atlantis JS -->
    <script src="<?php echo e(asset('assets/admin/js/atlantis.min.js')); ?>"></script>

    <!-- Atlantis DEMO methods, don't include it in your project! -->
    <script src="<?php echo e(asset('assets/admin/js/setting-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/demo.js')); ?>"></script>
</body>

</html>
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkp-master/resources/views/admin/login.blade.php ENDPATH**/ ?>