<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.1/dist/leaflet.css"
        integrity="sha512-Rksm5RenBEKSKFjgI3a41vrjkw4EVPlJ3+OiI65vTjIdo9brlAacEuKOiQ5OFh7cOI1bkDwLqdLw3Zg0cRJAAQ=="
        crossorigin="" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.Default.css" />

    <style>
        #mapid {
            min-height: 500px;
        }

        table tr th {
            text-align: center;
        }

        td {
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .card-artikel {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            width: 100%;
            border-radius: 13px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .card-artikel:hover {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .list-tile__title {
            margin: 0;
            font-size: 1.1em;
            color: #333;
            font-weight: bold;
        }

        .list-tile__subtitle {
            margin: 5px 0 0;
            font-size: 0.9em;
            color: #666;
        }
    </style>
    <br><br><br>
    <?php
        use App\Models\Tb_kategori_konten_ebook;
        use App\Models\Tb_kategori_konten;
        use App\Models\Tb_artikel;
        use App\Models\Tb_ebook;

        use Illuminate\Support\Carbon;
    ?>
    <div class="container mt-5"><br>
        <?php
            $atas_kiri = explode(',', $submenu->konten->halaman->atas_kiri);
            $atas_tengah = explode(',', $submenu->konten->halaman->atas_tengah);
            $atas_kanan = explode(',', $submenu->konten->halaman->atas_kanan);
            $tengah_kiri = explode(',', $submenu->konten->halaman->tengah_kiri);
            $tengah_tengah = explode(',', $submenu->konten->halaman->tengah);
            $tengah_kanan = explode(',', $submenu->konten->halaman->tengah_kanan);
            $bawah_kiri = explode(',', $submenu->konten->halaman->bawah_kiri);
            $bawah_tengah = explode(',', $submenu->konten->halaman->bawah_tengah);
            $bawah_kanan = explode(',', $submenu->konten->halaman->bawah_kanan);
        ?>
        
        <?php if($submenu->konten->halaman != ''): ?>
            <?php if($submenu->konten->halaman->judul): ?>
                <header class="section-header">
                    <p class="mt-4 text-uppercase"><?php echo e($submenu->konten->halaman->judul); ?></p>
                </header><br>
            <?php endif; ?>
            
            <div class="row">
                <?php if($submenu->konten->halaman->atas_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($atas_kiri[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($atas_kiri[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Artikel'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Artikel::class, []); ?>
<?php $component->withName('artikel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0)): ?>
<?php $component = $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0; ?>
<?php unset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Kalender Widget'): ?>
                    <div class="col-lg-4">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-widget','data' => []]); ?>
<?php $component->withName('kalender-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php
                    $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->atas_tengah);
                    $kategoriKontenEbook = Tb_kategori_konten_ebook::find($submenu->konten->halaman->atas_tengah);
                ?>
                <?php if($submenu->konten->halaman->atas_tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($atas_tengah[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($atas_tengah[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Video::class, []); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9)): ?>
<?php $component = $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9; ?>
<?php unset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Ebook::class, []); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a)): ?>
<?php $component = $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a; ?>
<?php unset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Kalender'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-besar','data' => []]); ?>
<?php $component->withName('kalender-besar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif(isset($kategoriKonten) && explode(',', $submenu->konten->halaman->atas_tengah)[1] == 'konten'): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->atas_tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 mt-3">
                                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                                <div class="row card-artikel">
                                                    <img src="<?php echo e($item->gambar()); ?>"
                                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                        alt="Avatar" class="col-2">
                                                    <div class="col">
                                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 30); ?></h3>
                                                        <span class="list-tile__subtitle"
                                                            style=""><?php echo e(Carbon::parse($artikel->tgl_pembuatan)->translatedFormat('D, d F Y')); ?>

                                                        </span>
                                                        <div class="text-primary">Lihat Detail</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>
                    </div>
                <?php elseif(isset($kategoriKontenEbook) && explode(',', $submenu->konten->halaman->atas_tengah)[1] == 'ebook'): ?>
                    <h4>Buku</h4>
                    <div class="col">
                        <?php
                            $ebook = Tb_ebook::where('id_kategori_konten_ebook', $submenu->konten->halaman->atas_tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $ebook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3">
                                            <div class="card shadow border-0 mb-2">
                                                <div class="card-body">
                                                    <center>
                                                        <div class=""><img src="<?php echo e($item->gambar()); ?>" class="rounded"
                                                                style="height: 200px; width: 100%; object-fit: cover;"
                                                                alt="">
                                                        </div>
                                                        <br>
                                                        <h6 class=""><b> <?php echo e(Str::limit($item->judul, 50)); ?> </b></h6>
                                                        <a href="/ebook/<?php echo e($item->kategoriEbook->nama); ?>/<?php echo e($item->slug); ?>"
                                                            class="readmore stretched-link mt-auto">
                                                        </a>
                                                    </center>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $ebook->links(); ?>

                        </center>
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->atas_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>


                    <!-- Galeri End -->
                <?php elseif($atas_kanan[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($atas_kanan[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Artikel'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Artikel::class, []); ?>
<?php $component->withName('artikel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0)): ?>
<?php $component = $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0; ?>
<?php unset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Kalender Widget'): ?>
                    <div class="col-lg-4">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-widget','data' => []]); ?>
<?php $component->withName('kalender-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if($submenu->konten->halaman->gambar != null): ?>
                <img style="width: 100%" class="rounded"
                    src="<?php echo e($submenu->konten->halaman ? $submenu->konten->halaman->gambar() : 'no_image'); ?>"
                    alt="Gambar">
            <?php endif; ?>

            <?php if($submenu->konten->halaman->teks): ?>
                <div class="card border-0">
                    <?php echo $submenu->konten->halaman->teks; ?>

                </div>
            <?php endif; ?>
            
            <hr>
            <?php
                $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->tengah);
                $kategoriKontenEbook = Tb_kategori_konten_ebook::find($submenu->konten->halaman->tengah);
            ?>
            <div class="row">
                <?php if($submenu->konten->halaman->tengah_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($tengah_kiri[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($tengah_kiri[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>

                    
                <?php elseif($submenu->konten->halaman->tengah_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah_kiri == 'Artikel'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Artikel::class, []); ?>
<?php $component->withName('artikel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0)): ?>
<?php $component = $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0; ?>
<?php unset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($tengah_tengah[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($tengah_tengah[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Video::class, []); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9)): ?>
<?php $component = $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9; ?>
<?php unset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Ebook::class, []); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a)): ?>
<?php $component = $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a; ?>
<?php unset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Kalender'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-besar','data' => []]); ?>
<?php $component->withName('kalender-besar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif(isset($kategoriKonten) && explode(',', $submenu->konten->halaman->tengah)[1] == 'konten'): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 mt-3">
                                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                                <div class="row card-artikel">
                                                    <img src="<?php echo e($item->gambar()); ?>"
                                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                        alt="Avatar" class="col-2">
                                                    <div class="col">
                                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 30); ?></h3>
                                                        <span class="list-tile__subtitle"
                                                            style=""><?php echo e(Carbon::parse($artikel->tgl_pembuatan)->translatedFormat('D, d F Y')); ?>

                                                        </span>
                                                        <div class="text-primary">Lihat Detail</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>
                        
                    </div>
                <?php elseif(isset($kategoriKontenEbook) && explode(',', $submenu->konten->halaman->tengah)[1] == 'ebook'): ?>
                    <h4>Karya Ilmiah</h4>
                    <div class="col">
                        <?php
                            $ebook = Tb_ebook::where('id_kategori_konten_ebook', $submenu->konten->halaman->tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $ebook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3">
                                            <div class="card shadow border-0 mb-2">
                                                <div class="card-body">
                                                    <center>
                                                        <div class=""><img src="<?php echo e($item->gambar()); ?>"
                                                                class="rounded"
                                                                style="height: 200px; width: 100%; object-fit: cover;"
                                                                alt="">
                                                        </div>
                                                        <br>
                                                        <h6 class=""><b> <?php echo e(Str::limit($item->judul, 50)); ?> </b>
                                                        </h6>
                                                        <a href="/ebook/<?php echo e($item->kategoriEbook->nama); ?>/<?php echo e($item->slug); ?>"
                                                            class="readmore stretched-link mt-auto">
                                                        </a>
                                                    </center>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $ebook->links(); ?>

                        </center>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Artikel'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Artikel::class, []); ?>
<?php $component->withName('artikel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0)): ?>
<?php $component = $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0; ?>
<?php unset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->tengah_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($tengah_kanan[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($tengah_kanan[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah_kanan == 'Artikel'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Artikel::class, []); ?>
<?php $component->withName('artikel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0)): ?>
<?php $component = $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0; ?>
<?php unset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            
            <div class="row">
                <?php if($submenu->konten->halaman->bawah_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($bawah_kiri[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($bawah_kiri[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_kiri == 'Artikel'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Artikel::class, []); ?>
<?php $component->withName('artikel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0)): ?>
<?php $component = $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0; ?>
<?php unset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php
                    $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->bawah_tengah);
                    $kategoriKontenEbook = Tb_kategori_konten_ebook::find($submenu->konten->halaman->bawah_tengah);
                ?>
                <?php if($submenu->konten->halaman->bawah_tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($bawah_tengah[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($bawah_tengah[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Video::class, []); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9)): ?>
<?php $component = $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9; ?>
<?php unset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Ebook::class, []); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a)): ?>
<?php $component = $__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a; ?>
<?php unset($__componentOriginal5bef6ea65f2077fdcb5e9371b73cb45826ddb74a); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Kalender'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kalender-besar','data' => []]); ?>
<?php $component->withName('kalender-besar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif(isset($kategoriKonten) && explode(',', $submenu->konten->halaman->bawah_tengah)[1] == 'konten'): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->bawah_tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 mt-3">
                                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                                <div class="row card-artikel">
                                                    <img src="<?php echo e($item->gambar()); ?>"
                                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                        alt="Avatar" class="col-2">
                                                    <div class="col">
                                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 30); ?></h3>
                                                        <span class="list-tile__subtitle"
                                                            style=""><?php echo e(Carbon::parse($artikel->tgl_pembuatan)->translatedFormat('D, d F Y')); ?>

                                                        </span>
                                                        <div class="text-primary">Lihat Detail</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>
                        
                    </div>
                <?php elseif(isset($kategoriKontenEbook) && explode(',', $submenu->konten->halaman->bawah_tengah)[1] == 'ebook'): ?>
                    <div class="col">
                        <?php
                            $ebook = Tb_ebook::where(
                                'id_kategori_konten_ebook',
                                $submenu->konten->halaman->bawah_tengah,
                            )
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $ebook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3">
                                            <div class="card shadow border-0 mb-2">
                                                <div class="card-body">
                                                    <center>
                                                        <div class=""><img src="<?php echo e($item->gambar()); ?>"
                                                                class="rounded"
                                                                style="height: 200px; width: 100%; object-fit: cover;"
                                                                alt="">
                                                        </div>
                                                        <br>
                                                        <h6 class=""><b> <?php echo e(Str::limit($item->judul, 50)); ?> </b>
                                                        </h6>
                                                        <a href="/ebook/<?php echo e($item->kategoriEbook->nama); ?>/<?php echo e($item->slug); ?>"
                                                            class="readmore stretched-link mt-auto">
                                                        </a>
                                                    </center>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $ebook->links(); ?>

                        </center>
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->bawah_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($bawah_kanan[1] == 'text'): ?>
                    <!-- text Start -->
                    <div class="col">
                        
                        <?php if (isset($component)) { $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Text::class, ['id' => ''.e($bawah_kanan[0]).'']); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb)): ?>
<?php $component = $__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb; ?>
<?php unset($__componentOriginal420f7c96ac3f84b969214fe410926b297dccb1fb); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Kontak::class, []); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e)): ?>
<?php $component = $__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e; ?>
<?php unset($__componentOriginal655073d2551b6fff5237460fb67e09b7e5a6a27e); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_kanan == 'Artikel'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Artikel::class, []); ?>
<?php $component->withName('artikel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0)): ?>
<?php $component = $__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0; ?>
<?php unset($__componentOriginal78fa0d9ce73443a04d7a740b5f0e91724d264ca0); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            
        <?php elseif($submenu->konten->artikel != ''): ?>
            <?php if($submenu->konten->artikel->gambar != null): ?>
                <img style="width: 100%" class="rounded"
                    src="<?php echo e($submenu->konten->artikel ? $submenu->konten->artikel->gambar() : 'no_image'); ?>"
                    alt="Gambar">
            <?php endif; ?>
            <h1 class="mt-4 text-uppercase"><?php echo e($submenu->konten->artikel->judul); ?></h1>
            <div class="card border-0">
                <?php echo $submenu->konten->artikel->teks; ?>

            </div>
        <?php elseif($submenu->konten->kegiatan != ''): ?>
            <?php if($submenu->konten->kegiatan->gambar != null): ?>
                <img style="width: 100%" class="rounded"
                    src="<?php echo e($submenu->konten->kegiatan ? $submenu->konten->kegiatan->gambar() : 'no_image'); ?>"
                    alt="Gambar">
            <?php endif; ?>
            <h1 class="mt-4 text-uppercase"><?php echo e($submenu->konten->kegiatan->judul); ?></h1>
            <div class="card border-0">
                <?php echo $submenu->konten->kegiatan->teks; ?>

            </div>
        <?php else: ?>
            <br><br><br>
            <center>Tidak Ada Konten</center>
            <br><br>
            <br>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkp-master/resources/views/member/submenu.blade.php ENDPATH**/ ?>